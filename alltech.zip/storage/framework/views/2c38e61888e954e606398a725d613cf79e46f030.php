<!-- Copyright -->

<div class="copyright">
    <div class="container">
        <div class="row">
            <div class="col">

                <div class="copyright_container d-flex flex-sm-row flex-column align-items-center justify-content-start">
                    <div class="copyright_content"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright &copy;<?php echo e(date('Y')); ?> All rights reserved

                    </div>
                    <div class="logos ml-sm-auto">






                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Laravel\alltech\resources\views/front/footer.blade.php ENDPATH**/ ?>